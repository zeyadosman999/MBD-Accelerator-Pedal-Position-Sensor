/*
 * File: Subsystem1.c
 *
 * Code generated for Simulink model 'Subsystem1'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Mar  9 02:02:57 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "Subsystem1.h"

/* External inputs (root inport signals with default storage) */
ExtU rtU;

/* External outputs (root outports fed by signals with default storage) */
ExtY rtY;

/* Real-time model */
static RT_MODEL rtM_;
RT_MODEL *const rtM = &rtM_;

/* Model step function */
void Subsystem1_step(void)
{
  /* Outputs for Atomic SubSystem: '<Root>/Subsystem1' */
  /* Outport: '<Root>/Out1' incorporates:
   *  Constant: '<S2>/Constant'
   *  Constant: '<S3>/Constant'
   *  Inport: '<Root>/u'
   *  Logic: '<S1>/Logical Operator'
   *  RelationalOperator: '<S2>/Compare'
   *  RelationalOperator: '<S3>/Compare'
   */
  rtY.Out1 = ((rtU.sensor1 > 4.5) || (rtU.sensor1 < 0.5));

  /* Outport: '<Root>/Out2' incorporates:
   *  Constant: '<S4>/Constant'
   *  Constant: '<S5>/Constant'
   *  Inport: '<Root>/u1'
   *  Logic: '<S1>/Logical Operator1'
   *  RelationalOperator: '<S4>/Compare'
   *  RelationalOperator: '<S5>/Compare'
   */
  rtY.Out2 = ((rtU.sensor2 > 4.5) || (rtU.sensor2 < 0.5));

  /* Outport: '<Root>/y' incorporates:
   *  Constant: '<S6>/Constant'
   *  Inport: '<Root>/u'
   *  Inport: '<Root>/u1'
   *  RelationalOperator: '<S6>/Compare'
   *  Sum: '<S1>/Sum'
   */
  rtY.y = (rtU.sensor2 + rtU.sensor1 != 5.0);

  /* End of Outputs for SubSystem: '<Root>/Subsystem1' */
}

/* Model initialize function */
void Subsystem1_initialize(void)
{
  /* (no initialization code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
